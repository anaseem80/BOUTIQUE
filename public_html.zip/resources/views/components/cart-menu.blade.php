<div class="div-header-circles cart-header-circles me-2 pt-1">
                <span class="notifications-number top-0 start-100 badge rounded-pill">{{ $item->product->name }}</span>
            <span class="bi bi-cart-fill"></span>
            </div>
            <span>السلة : </span>
            <span> {{ $item->product->name }} </span>
            <span> د.ك </span>