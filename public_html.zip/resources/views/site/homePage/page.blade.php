@extends('layouts.layoutSite.SitePage')
@section('title','عقارات للايجار')
@section('content')


@stop

@section('script')

@stop

