
 <!-- Jquery Core Js -->
<script src="{{ url('/') }}/cp/assets/bundles/libscripts.bundle.js"></script>

<!-- Plugin Js -->
<script src="{{ url('/') }}/cp/assets/bundles/apexcharts.bundle.js"></script>
<script src="{{ url('/') }}/cp/assets/bundles/dataTables.bundle.js"></script>  

<!-- Jquery Page Js -->
<script src="{{ url('/') }}/cp/js/template.js?<?=time()?>"></script>
<script src="{{ url('/') }}/cp/js/page/index.js"></script>